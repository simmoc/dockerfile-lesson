
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
var s="./assets/email.e60c9c48.svg",a="./assets/link_icon.a64d47a1.svg",_="./assets/man.2a48e04a.svg",e="./assets/no_trend.4b87e4e1.svg",o="./assets/ognization.78cdcc9c.svg",t="./assets/phone.4efbaa54.svg",g="./assets/women.356695cc.svg";const c={0:"\u672A\u77E5\u6765\u6E90",1:"\u626B\u63CF\u4E8C\u7EF4\u7801",2:"\u641C\u7D22\u624B\u673A\u53F7",3:"\u540D\u7247\u5206\u4EAB",4:"\u7FA4\u804A",5:"\u624B\u673A\u901A\u8BAF\u5F55",6:"\u5FAE\u4FE1\u8054\u7CFB\u4EBA",7:"\u6765\u81EA\u5FAE\u4FE1\u7684\u6DFB\u52A0\u597D\u53CB\u7533\u8BF7",8:"\u5B89\u88C5\u7B2C\u4E09\u65B9\u5E94\u7528\u65F6\u81EA\u52A8\u6DFB\u52A0\u7684\u5BA2\u670D\u4EBA\u5458",9:"\u641C\u7D22\u90AE\u7BB1",201:"\u5185\u90E8\u6210\u5458\u5171\u4EAB",202:"\u7BA1\u7406\u5458/\u8D1F\u8D23\u4EBA\u5206\u914D"},v={1:"\u4E92\u4E3A\u597D\u53CB\u5173\u7CFB",2:"\u6210\u5458\u5220\u9664\u5BA2\u6237",3:"\u5BA2\u6237\u5220\u9664\u6210\u5458"},n="http://we-customer-api.freshgood.cn/upload/source_2022/01/26/fiRGqmzI8Dv4KbuSnTsNkOYQAL19VW7r.png";export{v as D,c as Q,s as _,a,_ as b,e as c,n as d,o as e,t as f,g};
